package xyz.coresynapses.oogwayserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OogwayserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(OogwayserverApplication.class, args);
	}

}
